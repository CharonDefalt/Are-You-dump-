from tkinter import *
import random
FONT = ("Arial", 12)


def yes_fool():
    new_label = Label(text="Congratulations! you are a fool", font=("Arial", 18, "bold"))
    new_label.place(x=75, y=15)


def no_fool():
    random_x = random.randint(100, 380)
    random_y = random.randint(100, 380)
    text_label.place(x=random_x, y=random_y)
    yes_button.place(x=random_x, y=random_y + 25)
    no_button.place(x=random_x + 100, y=random_y + 25)


window = Tk()
window.minsize(width=500, height=500)
window.title("Are you a fool?")
window.config(padx=25, pady=25)

text_label = Label(text="Are you a Fool?", font=FONT)
text_label.place(x=0, y=50)
yes_button = Button(text="yes", command=yes_fool)
yes_button.place(x=0, y=75)
no_button = Button(text="no", command=no_fool)
no_button.place(x=100, y=75)

window.mainloop()
